package easekolar.subjects;

public interface Subject {

    // * This should contain all functionalities that a subject should have.

}